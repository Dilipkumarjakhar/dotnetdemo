﻿namespace WebApplicationwithApiAndAngular.Models
{
    public class Place
    {
        public Guid PlaceId { get; set; }
        public string PlaceName { get; set; }
    }
}
